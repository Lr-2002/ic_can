//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// G_vctr_fcn_types.h
//
// Code generation for function 'G_vctr_fcn'
//

#pragma once

// Include files
#include "rtwtypes.h"
#include "emlrt.h"

// End of code generation (G_vctr_fcn_types.h)
