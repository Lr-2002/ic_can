/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: regressorWithMotorDynamics_data.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2025-10-15 20:55:52
 */

#ifndef REGRESSORWITHMOTORDYNAMICS_DATA_H
#define REGRESSORWITHMOTORDYNAMICS_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#endif
/*
 * File trailer for regressorWithMotorDynamics_data.h
 *
 * [EOF]
 */
