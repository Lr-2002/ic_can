/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: standard_regressor.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2025-10-15 20:55:52
 */

#ifndef STANDARD_REGRESSOR_H
#define STANDARD_REGRESSOR_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void ft_1(const double ct[335], double Y_f[360]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for standard_regressor.h
 *
 * [EOF]
 */
