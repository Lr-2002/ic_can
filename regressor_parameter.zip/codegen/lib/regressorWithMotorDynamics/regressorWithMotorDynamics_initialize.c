/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: regressorWithMotorDynamics_initialize.c
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2025-10-15 20:55:52
 */

/* Include Files */
#include "regressorWithMotorDynamics_initialize.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void regressorWithMotorDynamics_initialize(void)
{
}

/*
 * File trailer for regressorWithMotorDynamics_initialize.c
 *
 * [EOF]
 */
