/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: frictionRegressor_terminate.c
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 2025-10-15 21:00:21
 */

/* Include Files */
#include "frictionRegressor_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void frictionRegressor_terminate(void)
{
}

/*
 * File trailer for frictionRegressor_terminate.c
 *
 * [EOF]
 */
