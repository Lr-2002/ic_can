//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// _coder_G_vctr_fcn_info.h
//
// Code generation for function 'G_vctr_fcn'
//

#pragma once

// Include files
#include "mex.h"

// Function Declarations
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

// End of code generation (_coder_G_vctr_fcn_info.h)
